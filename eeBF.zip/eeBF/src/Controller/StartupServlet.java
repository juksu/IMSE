package Controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/StartupServlet")
public class StartupServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public StartupServlet()
    {

    }
}
