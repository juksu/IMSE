package Model;

public class login 
{
	private User user;
	
	public login() 
	{
		throw new UnsupportedOperationException();
	}

	public void registrieren() 
	{
		throw new UnsupportedOperationException();
	}

	public void passwortVergessen()
	{
		throw new UnsupportedOperationException();
	}

	public void createUserFunctions()
	{
		throw new UnsupportedOperationException();
	}

	public User getUser() 
	{
		return user;
	}

	public void setUser(User user)
	{
		this.user = user;
	}
}